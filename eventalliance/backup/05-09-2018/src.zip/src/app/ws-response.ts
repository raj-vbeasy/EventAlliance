export class WSResponse {
    public id: number;
    public status: boolean;
    public message: string;
}
<?php
    ob_start();
    session_start();
    error_reporting(0);
    

    $link = mysqli_connect('localhost','santosh2017','9ZPqO?RMHvyS','mycraftsindia') or die('Error '.mysqli_error($link)); 
   


    
?>
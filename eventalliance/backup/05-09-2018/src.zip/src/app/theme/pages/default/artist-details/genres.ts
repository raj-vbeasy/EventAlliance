
export class Genres {
    id: number;
    name: string;



    constructor() {
        this.reset();
    }

    public reset() {
        this.id = 0;
        this.name = "";


    }
}
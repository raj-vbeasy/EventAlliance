import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../helpers';


@Component({
    selector: "app-venues",
    templateUrl: "./venues.component.html",
    encapsulation: ViewEncapsulation.None,
})
export class VenuesComponent implements OnInit {


    constructor() {

    }
    ngOnInit() {

    }

}
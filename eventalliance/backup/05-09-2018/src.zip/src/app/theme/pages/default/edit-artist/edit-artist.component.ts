import { Component, OnInit, ViewEncapsulation, AfterViewInit } from '@angular/core';
import { Helpers } from '../../../../helpers';
import { ScriptLoaderService } from '../../../../_services/script-loader.service';


@Component({
    selector: "app-artists",
    templateUrl: "./edit-artist.component.html",
    encapsulation: ViewEncapsulation.None,
})
export class EditArtistComponent implements OnInit {


    constructor() {

    }
    ngOnInit() {

    }


}
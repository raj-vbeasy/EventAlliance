import { Component, OnInit, ViewEncapsulation, AfterViewInit } from '@angular/core';
import { Helpers } from '../../../../helpers';
import { ScriptLoaderService } from '../../../../_services/script-loader.service';


@Component({
    selector: "app-artist-availability",
    templateUrl: "./artist-availability.component.html",
    encapsulation: ViewEncapsulation.None,
})
export class ArtistAvailabilityComponent implements OnInit {


    constructor() {

    }
    ngOnInit() {

    }


}
<?php

 namespace App\Controller;
 
 use App\Controller\AppController;
 use Cake\Event\Event;
 use Cake\ORM\TableRegistry;
 
 class UploadsController extends AppController{
    public function index(){
       echo "EventAlliance Api ";exit;
    }
    
   
 }
